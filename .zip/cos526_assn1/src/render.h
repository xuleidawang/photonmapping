// Include file for the photon map render code

R2Image *RenderImage(R3Scene *scene, int width, int height, int print_verbose);

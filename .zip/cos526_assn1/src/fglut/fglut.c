// Source file for fglut package stand-in



// These are never used.  They are just dummy functions
// to compile and link when the native glut is used, and 
// thus the rest of the code in the fglut package is not
// compiled



int R3InitGlut(void)
{
    // return OK status 
    return 1;
}



void R3StopGlut(void)
{
}






